function toggleHidClassBasedOnBodyWidth(maxWidth) {
    var bodyWidth = document.body.clientWidth;
    var hidElements = document.querySelectorAll('.hid');
    var hidelements2 = document.querySelector('.third');
    if (bodyWidth < maxWidth) {
        hidelements2.style.display = 'none';
        document.querySelector('.first').style.bodyWidth = "30px"
    } else {
        hidelements2.style.display = 'block';
    }
    hidElements.forEach(function (element) {
        if (bodyWidth < maxWidth) {
            element.style.display = 'none';
        } else {
            element.style.display = 'block';
        }
    });
}
var a = document.querySelector('#btn1');
var b = document.querySelector('#btn2');
var maxWidth = 1024;
var follow = document.querySelectorAll('#follow')
toggleHidClassBasedOnBodyWidth(maxWidth);

window.addEventListener('resize', function () {
    toggleHidClassBasedOnBodyWidth(maxWidth);
});
a.addEventListener('click', function () {
    a.style.fontWeight = "700";
    b.style.fontWeight = "normal";
});
b.addEventListener('click', function () {
    b.style.fontWeight = "700";
    a.style.fontWeight = "normal";
});
const followButtons = document.querySelectorAll('#follow');
followButtons.forEach(button => {
    button.addEventListener('click', function () {
        if (button.textContent === 'Follow') {
            button.textContent = 'Followed';
        } else {
            button.textContent = 'Follow';
        }
    });
});
let form=document.getElementById('form')
let postcontent;

let inputpic = document.getElementById("input-file");
let src;
function createCard() {
    
}

let post = document.querySelector(".postimg");

// Add event listener to the selected element

form.addEventListener('submit',function(event){
    event.preventDefault();
    postcontent=document.getElementById('textInput').value;
    inputpic.onchange= function(){
        src=URL.createObjectURL(inputpic.files[0]);
    }
})
post.addEventListener('click', function () {
    var container = document.querySelector('.posts');
    container.innerHTML += '<div class="cards"><div> '+postcontent+' <div/><img src="' +src+'"></div>';
    
    
});